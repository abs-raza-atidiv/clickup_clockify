
CLICKUP_TASK = 'clickup_task'

CLOCKIFY_CLIENT = 'clockify_client'
CLOCKIFY_TASK = 'clockify_task'

CLOCKIFY_PROJECT = 'clockify_project'

ASANA_TASKS = 'asana_task'